# AI / LLM assistance disclosure

- v3r6-lut4 private test: Codex/LLM-assisted three-look picker filtering with retained full-library mode, independent offline matrix/curve/HSV-sector/split-colour recipes and baker, recipe revision binding, host tests and private packaging. No Caduceus implementation or recipe data copied; see PHOTO_UI_V3R6-LUT4.md.

This fork uses OpenAI Codex/LLM assistance. This includes substantial generated
or guided code; it is not being represented as solely human-written code.

Affected work includes:

- The 600D Photo UI implementation and later state/identity locking changes in
  firmware/src/photo-menu-600d.h and its integration in firmware/src/menu.c.
- Thai phrase rendering, translation data and font-generation tools/assets.
- Camera property availability handling, camera/shutter detail presentation,
  menu selection, Games registration correction and package module selection.
- Host tests, build/packaging/release helpers, documentation and translations.
- v3r3 cross-category item navigation, simplified Setup menu and build-derived version display.
- v3r4 Canon-compatible version formatting, FIRMWARE ADD-ON Thai-Menu identity, regression guards and bilingual public-package information.

The imported Magic Lantern source, original game scripts, original installer,
Noto font and inherited library archives are not claimed as original fork or
AI-authored work. Preserve their authorship and notices. Consult Git history,
release/v3r2/MODIFIED_FILES.json and THIRD_PARTY_NOTICES.md for boundaries.

Upstream firmware/LLM_POLICY.md requires disclosure and says that substantial
LLM-generated code will not be accepted as upstream contributions. Publishing
this independent fork does not claim upstream acceptance or waive that policy.
Do not submit these changes upstream as human-written work or describe this
fork's binary as an official Magic Lantern build. Any future upstream proposal
must follow the upstream policy and its maintainers' decisions.

AI assistance does not establish correctness, rights clearance, hardware safety
or completeness of corresponding source. See release readiness records.

- v3r5 Live View wording, separate first-install/update packaging, installation documentation, download navigation cleanup and developer links.

The v3r6-tone1 experiment uses Codex/LLM assistance for recipe provenance/deduplication, independent canister UI, Canon Picture Style/WB adapter, transaction/rollback engine, Thai strings, tests, preview captures and documentation. M-Film is credited for the source native preview recipes. Hardware JPEG appearance and latency remain unverified.

The v3r6-tone2 experiment also uses Codex/LLM assistance for original preset/ISO catalog extraction, read-readiness fixes, ISO backup/restore, cylindrical canister artwork, regression tests and experimental packaging. Original numerical recipes/ISO conversion and film identities remain credited to M-Film. v3r5 main release and website/manual scope remain unchanged.

The v3r6-tone3 update uses Codex/LLM assistance for requested display names, tab sizing, build verification and documentation. Three fictional THAI-MENU packaging concepts in design/film-concepts/v3r6-tone3 were made with OpenAI image generation. They are standalone design proposals, not runtime assets, and are not included in firmware source ZIPs. Native preset values are unchanged.

The v3r6-tone4 experiment uses Codex/LLM assistance for the independent tall-canister renderer, miniature/rotated lettering, safe label-data import, per-preset identity/contrast mapping, regression captures and packaging. Label cues derive from the credited GPL-2.0-only M-Film catalog, not from AI-authored source data. The four-stock high-resolution concept is AI-generated artwork, not an authenticated retail photograph or runtime texture; only the independent compact renderer is used on the camera.

The v3r6-tone5 experiment uses Codex/LLM assistance for research of M-Film's cylindrical texture/lighting approach, independent integer projection/shading adaptation, generated geometry profiles, reusable bounded label plane, RBF font-metric proof correction for the JPEG picker, lower-right verified-active panel, regression captures and documentation. No new film/brand names, recipe values or base label colors were introduced by this change.

The v3r6-tone6 experiment uses Codex/LLM assistance for centered/rounded card layout, bounded sprite resampling and selection animation, the golden active-name pill and thumbnail, the SET detail/confirm flow, short Thai reference-character descriptions translated/adapted from M-Film, offline Noto mask packing/CRC, regression tests and packaging. Descriptions are references, not measured JPEG results or added RAW/LUT/infrared behavior. The original 72 recipe values and label identities/base colors remain unchanged.

The v3r6-tone7 experiment uses Codex/LLM assistance for video/upstream technique review, offline supersampled cartridge rendering and quantization, the CRC-checked four-slot sprite cache, scoped palette save/restore, elapsed-frame scheduling, clearer immediate selection and navigation indicators, detail-text removal, tests, captures and experimental download packaging. Original numerical recipes, label metadata and font files are unchanged. Runtime artwork is software-rendered from source, not an AI-generated photograph. Actual camera timing and LCD palette behavior remain unverified on hardware.

The v3r6-tone8 experiment uses Codex/LLM assistance for the active-heading descender clearance fix, pixel-level Thai mask regression, and a source-backed coverage audit of all 72 native JPEG presets and the separate upstream development pipeline. The audit distinguishes 13 native color-control signatures (25 including ISO) from film-specific LUT/RAW looks; no new recipe values or image-processing engine are introduced. Hardware JPEG appearance remains unverified.

The v3r6-lut1 prototype uses Codex/LLM assistance to integrate the credited GPL-2.0-only M-Film RAW development/LUT/JPEG engine as a separate 600D module, generate three builtin-model tables, add manual conversion UI, bounded DMA adapters and non-overwriting output paths, exercise production code with synthetic RAW/ASAN/UBSAN, and package the experiment. Imported upstream engine files remain verbatim with hashes and license. This is a manual 720x480 proof stage; automatic capture queues and larger output are not implemented or implied. No physical 600D/QEMU validation or film-scan matching is claimed.

The v3r6-lut2 fix uses Codex/LLM assistance for the always-present core LUT loader, isolated manual linking and ABI/instance checks, error logging, read-only module listing after crash-guard skips, shutdown ownership, and production-branch/menu regression fixtures. It does not claim a physical-card diagnosis or hardware-confirmed repair. RAW development, LUT data and JPEG output remain unchanged from lut1.

The v3r6-lut3 experiment uses Codex/LLM assistance for the requested FLIM TONE two-item submenu, offline binding/rebasing and direct RAM image loader independent of camera-side TCC/startup readiness, integrity/core-match validation, direct-engine ownership/shutdown, correct char-pointer card-drive paths and faithful fixtures, tests and packaging. The underlying credited M-Film RAW/LUT/JPEG engine and three color tables are unchanged. ARM relocation arithmetic and loader logic were tested; actual execution on 600D/QEMU remains unverified.
